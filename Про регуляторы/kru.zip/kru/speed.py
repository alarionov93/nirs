from chasis import Chasis  #управление шасси
from network import ping # сеть
import io # ввод/вывод
from urllib.request import urlopen # обработка url
from time import sleep # подругаем из time только slaeep
from datetime import datetime
from threading import Thread

# переменные
regulate_end = 0

# исходные

V_target = 5 # целевая скорость в м/с
А = 0.0

# ПИД



# коэффициенты
Kp = 0.6 # 120.0
Ki = 0.075/2000#.242*2 # .25 # 242.0
Kd = 0#.0097 #.125 # 5.0

#файл лога
log=open("log.txt","w")

def getV_now():
	r = 0.2447 * chasis.Acceleration.pos1 - 7.5565
	if r < 0:
		r = 0
	return r #chasis.Position.Vn
 
def calculate_A(U):
	A = 4.05 * U + 31
	if U == 0:
		A = 0
	if A > 44:
		A = 44
	if A < 0:
		A = 0
	return A


def regulate():# регулятор
	U_result = 0.0
	U_old = 0.0

	T_now = 0.0 # текущее время
	T_last = 0.0 # время прошлого цикла
	V_now = 0.0 # текущая скорость в м/с
	# V_target
	E_now = 0.0 # ошибка текущая
	E_last = 0.0 # обшибка прошлого цикла
	S = 0.0 # сумма
	P = 0.0 # пропорциональная 
	D = 0.0 # дифференциальная
	I = 0.0 # интегральная
	U_reg = 0.0 # результат регулятора
	global А # результат регулятора в попугаях

	T_delta = 0.0 # приращение времени

	T_last = datetime.now()


	# получем текущие значения
	while not regulate_end:
		T_now = datetime.now()
		T_delta = T_now - T_last
		T_delta = T_delta.seconds+T_delta.microseconds/1000000
		
		V_now = getV_now()
		E_now = V_target - V_now

		try:
			P = Kp * E_now
			D = Kd * ((E_now - E_last) / T_delta) # деление на 0... как?
			S += ((E_now + E_last) * T_delta)/2
			I = Ki * S
			U_reg = P + I + D
		except ZeroDivisionError:
			U_reg = 0
		U_result = U_old + (U_reg - U_old)

		

		A = calculate_A(U_result)
		chasis.Acceleration.pos0 = A

		U_old = U_result
		# print(A)

		sleep(0.051)
		# print("%s %s %s %s %s %s %s %s %s %s %s %s\n"\
			 # %(T_now, T_last, V_target, V_now, E_now, E_last, S, P, D, I, U_reg, A))
		log.write("%s %s %s %s %s %s %s %s %s %s %s %s\n"\
			%(T_now, T_last, V_target, V_now, E_now, E_last, S, P, D, I, U_reg, A))
		E_last = E_now

		T_last = T_now

# V_target 1 		1
# V_now 	0 		3.2103
# E_now 	1 		-2.2103
# E_last 	0 		1
# S 		0.50	0.9052945046499999
# P 		120.0 	-265.236
# D 		4.942	-15.86635549769737
# I 		122.41	219.0812701253
# U_reg 	247.3	-62.021085372397366
# A 		44 		0
	# переводим скорость в попугаях
	# скорость выводим в попугаях 
	log.close()

#######################################################################
if __name__ == "__main__": # точка входа
	chasis = Chasis() #создание шасси

	V_target = 0

	regulate_thread = Thread(target = regulate) # туда
	regulate_thread.start() # запуск потока
			
	sleep(2)
# получаем стартовые значения
	V_target = 2
	sleep(15)
	V_target = 0


#######################################################################
#	while 1: # бесконечный цикл выполнения регулятора
		# A = regulate(V,V0) # запуск регулятора, А - результат работы цикла регулирования
		# выводим рещультат регулятора на МРК
		# записываем данные в файл
#######################################################################

#	chasis.more()
	sleep(6)
	regulate_end = 1 # метка окончания потока
	regulate_thread.join()
	chasis.finish()
