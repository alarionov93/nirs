from network import *
from threading import Thread
from time import sleep
# список команд применимых к шасси
# получаем текущую скорость
cmd_get_speed    	     = 'http://iisu/orientation/speed'
# получаем текущее положение
cmd_get_orientation	     = 'http://iisu/orientation/get' 
# остановка робота с включением тормозов
cmd_engine_stop          = 'http://iisu/engine/stop' 
#установить направление и скорость
cmd_move_set_acc_steer	 = 'http://iisu/move/set_acc_steer' 
#параметры, передаваемые в команде
prm_move_set_acc_steer	 = "req_acc_pos=%i&rgt_brk=%i&lgt_brk=%i&req_str_pos=%i" 
#возвращает состояние
cmd_get_state	         = 'http://iisu/state' 
#текущее значение желаемой скорости
cmd_get_accpos			 = 'http://iisu/engine/get_pos' 


class Chasis(object):
	end  = 0
	maxAccPos = 44 # максимальная скорость 

	class Acceleration: # скорость
		pos0  = 0 # хотим
		pos1  = 0 # получилось

	class Brakes: # тормоза
		right = 0 
		left  = 0
		main  = 0 # передние

	class Position: #положение
		x     = 0 # координаты
		y     = 0 #
		azm   = 0 # азимут
		Vn	  = 0 # Скорость
		Vh	  = 0
		Ve	  = 0
        An    = 0 # углы наклона БИНС
        Ah    = 0
        Ae    = 0

	def finish(self, *argc): # остановка потоков
		self.end = 1 # метка окончания потока
		for _ in [self.azm_thread, self.acc_thread, self.upd_thread]:
			_.join() # завершение потока/возврат потока в основной
	def __init__(self, *args, **kwargs): #конструктор
		self.azm_thread = Thread(target = self.get_orientation) # прием
		self.acc_thread = Thread(target = self.get_acc_pos) # прием
		self.upd_thread = Thread(target = self.update) # отправка
		for _ in [self.azm_thread, self.acc_thread, self.upd_thread]:
			_.start() # запуск потоков
			sleep(0.3)
	def update(self): # обновление состояния
		steering_pos     = 0
		acceleration_pos = 0
		brakes_right     = 0
		brakes_left      = 0
		brakes_main      = 0
		while not self.end:
			res = {} # словарь
			# проверяем, изменились ли нужные нам параметры
			if True or acceleration_pos != self.Acceleration.pos0 or \
			   brakes_left      != self.Brakes.left or \
			   brakes_right     != self.Brakes.right:
				# пакуем нужные параметры в post-запрос (получаем ответ в Json)
				res.update(post_json_url_to_dict(
					cmd_move_set_acc_steer, 
					prm_move_set_acc_steer,
					(
						self.Acceleration.pos0,
						self.Brakes.right,
						self.Brakes.left,
						steering_pos
					)
				))
				# обновление значений из тех, которые получили
				acceleration_pos = self.Acceleration.pos0
				brakes_right = self.Brakes.right
				brakes_left = self.Brakes.left
				brakes_main = self.Brakes.main
			sleep(0.01)
		self.stop()
    # получение положения
	def get_orientation(self):
		#f = open('/tmp/spd', 'w')
		while not self.end:
			try:
				_ = get_json_url_to_dict(cmd_get_orientation)
				_.update(get_json_url_to_dict(cmd_get_speed))
				self.Position.azm = _['A_bins'] - 180
				self.Position.x   = round(_['x'],4)
				self.Position.y   = round(_['y'],4)
				self.Position.Vn  = round(_['V_n'],4)
				self.Position.Vh  = round(_['V_h'],4)
				self.Position.Ve  = round(_['V_e'],4)
			except KeyError:
				self.Position.azm = 0
				self.Position.x = 0
				self.Position.y = 0
			sleep(0.5)
    # получение занчения, выставленного на управлении двигателем
	def get_acc_pos(self):
		while not self.end:
			try:
				_ = get_json_url_to_dict(cmd_get_accpos)
				if _['ok']:
					self.Acceleration.pos1 = _['currentAccelPos']
				else:
					self.Acceleration.pos1 = None
			except KeyError:
				self.Acceleration.pos1 = None
			sleep(0.3)
    # включаем левый задний тормоз
	def lbrake(self, *argc):
		if self.Brakes.left: self.Brakes.left = 0
		else: self.Brakes.left = 1
    # включаем правый задний тормоз
	def rbrake(self, *argc):
		if self.Brakes.right: self.Brakes.right = 0
		else: self.Brakes.right = 1
    # выключаем двигатель, включаем тормоза
	def stop(self, *argc):
		res = get_json_url_to_dict(cmd_engine_stop)
		self.Acceleration.pos0 = 0 # желаемая скорость=0
# точка входа
if __name__ == "__main__":
	chasis = Chasis()
	sleep(2)
	print(chasis.Position.Vn)
	sleep(2)
	chasis.finish()