from network import *
from threading import Thread
from time import sleep

# список команд применимых к шасси
# получаем текущую скорость
cmd_get_speed    	     = 'http://iisu/orientation/speed'
# получаем текущее положение
cmd_get_orientation	     = 'http://iisu/orientation/get' 
# остановка робота с включением тормозов
cmd_engine_stop          = 'http://iisu/engine/stop' 
#установить направление и скорость
cmd_move_set_acc_steer	 = 'http://iisu/move/set_acc_steer' 
#параметры, передаваемые в команде
prm_move_set_acc_steer	 = "req_acc_pos=%i&rgt_brk=%i&lgt_brk=%i&req_str_pos=%i" 
#возвращает состояние
cmd_get_state	         = 'http://iisu/state' 
#текущее значение желаемой скорости
cmd_get_accpos			 = 'http://iisu/engine/get_pos' 


class Chasis(object):
	end  = 0
	maxAccPos = 44 # максимальная скорость 

	class Acceleration: # скорость
		pos0  = 0 # хотим
		pos1  = 0 # получилось

	class Brakes: # тормоза
		right = 0 
		left  = 0
		main  = 0 # передние

	class Position: #положение
		x     = 0 # координаты
		y     = 0 #
		azm   = 0 # азимут
		Vn	  = 0 # Скорость
		Vh	  = 0
		Ve	  = 0
        An    = 0 # углы наклона БИНС
        Ah    = 0
        Ae    = 0



	def finish(self, *argc): # остановка потоков
		self.end = 1 # метка окончания потока
		for _ in [self.azm_thread, self.acc_thread, self.upd_thread]:
			_.join() # завершение потока/возврат потока в основной

	def __init__(self, *args, **kwargs): #конструктор
		self.azm_thread = Thread(target = self.get_orientation) # прием
		self.acc_thread = Thread(target = self.get_acc_pos) # прием
		self.upd_thread = Thread(target = self.update) # отправка
		for _ in [self.azm_thread, self.acc_thread, self.upd_thread]:
			_.start() # запуск потоков
			sleep(0.3)

	def update(self): # обновление состояния
		steering_pos     = 0
		acceleration_pos = 0
		brakes_right     = 0
		brakes_left      = 0
		brakes_main      = 0
		while not self.end:
			res = {} # словарь
			# проверяем, изменились ли нужные нам параметры
			if True or acceleration_pos != self.Acceleration.pos0 or \
			   brakes_left      != self.Brakes.left or \
			   brakes_right     != self.Brakes.right:
				# пакуем нужные параметры в post-запрос (получаем ответ в Json)
				res.update(post_json_url_to_dict(
					cmd_move_set_acc_steer, 
					prm_move_set_acc_steer,
					(
						self.Acceleration.pos0,
						self.Brakes.right,
						self.Brakes.left,
						steering_pos
					)
				))
				# обновление значений из тех, которые получили
				acceleration_pos = self.Acceleration.pos0
				brakes_right = self.Brakes.right
				brakes_left = self.Brakes.left
				brakes_main = self.Brakes.main
			sleep(0.01)
		self.stop()
    # получение положения
	def get_orientation(self):
		#f = open('/tmp/spd', 'w')
		while not self.end:
			try:
				_ = get_json_url_to_dict(cmd_get_orientation)
				_.update(get_json_url_to_dict(cmd_get_speed))
				self.Position.azm = _['A_bins'] - 180
				self.Position.x   = round(_['x'],4)
				self.Position.y   = round(_['y'],4)
				self.Position.Vn  = round(_['V_n'],4)
				self.Position.Vh  = round(_['V_h'],4)
				self.Position.Ve  = round(_['V_e'],4)
			except KeyError:
				self.Position.azm = 0
				self.Position.x = 0
				self.Position.y = 0

			sleep(0.5)
    # получение занчения, выставленного на управлении двигателем
	def get_acc_pos(self):
		while not self.end:
			try:
				_ = get_json_url_to_dict(cmd_get_accpos)
				if _['ok']:
					self.Acceleration.pos1 = _['currentAccelPos']
				else:
					self.Acceleration.pos1 = None
			except KeyError:
				self.Acceleration.pos1 = None
			sleep(0.3)
    # включаем левый задний тормоз
	def lbrake(self, *argc):
		if self.Brakes.left: self.Brakes.left = 0
		else: self.Brakes.left = 1
    # включаем правый задний тормоз
	def rbrake(self, *argc):
		if self.Brakes.right: self.Brakes.right = 0
		else: self.Brakes.right = 1
    # выключаем двигатель, включаем тормоза
	def stop(self, *argc):
		res = get_json_url_to_dict(cmd_engine_stop)
		self.Acceleration.pos0 = 0 # желаемая скорость=0
# точка входа
if __name__ == "__main__":
	chasis = Chasis()
	sleep(2)
	print(chasis.Position.Vn)
	sleep(2)
	chasis.finish()

"""
{
    "KHC": {
        "ok": true,
        "is_lgt_brake": false,
        "is_reverse": false,
        "enc_sec": 0,
        "is_frw_brake": true,
        "is_rgt_brake": false,
        "enc_min": 0,
        "currentAccelPos": 0
    },
    "KRU": {
        "flickerState": 0,
        "flickersMode": 2,
        "flk_offTime": 60,
        "flk_onTime": 60,
        "currentRudderPos": 0,
        "rudderState": 11,
        "LIM_RIGHT": 0,
        "maxRudderPos": 17,
        "ok": true,
        "mdlRudderPos": 52,
        "targetRudderPos": 0,
        "minRudderPos": -17,
        "LIM_LEFT": 0
    },
    "CV": {
        "state": "NORMAL_OP",
        "errors": {
            "rot": 0,
            "rng": 0,
            "rec": 0
        },
        "current_cam": "left",
        "ok": true,
        "pos": {
            "a": 2,
            "b": 1
        }
    },
    "BUP": {
        "ok": true,
        "PIN_power_12": true,
        "PIN_power_48": false,
        "U_12": 11.6,
        "I_48": 0.59,
        "I_12": 5.5,
        "PIN_power_self": true
    },
    "BINS": {
        "C_bins": -170.8363494873047,
        "0x33": {
            "len": 83,
            "present": true
        },
        "W_x": 0.00551198236644268,
        "0x34": {
            "len": 63,
            "present": true
        },
        "A_bins": 28.875165939331055,
        "state": {
            "obj_move": false,
            "sns_ok": true,
            "sns_crr": 0,
            "avt_md": 0,
            "dbl_hyr_rpt": true,
            "odo_crr": true,
            "sns_good": 0,
            "ready": 1,
            "lat_crr": 0,
            "bv_ok": false,
            "stb_crr": 1,
            "cur_lat_crr": 0,
            "ins_ok": true,
            "mk_ok": false,
            "dbl_hyr": true,
            "dvs_good": false,
            "r0": 0,
            "zav_crr": 0,
            "acc_crr": true
        },
        "0x35": {
            "len": 71,
            "present": true
        },
        "0x85": {
            "len": 163,
            "present": true
        },
        "A_y": -0.9878328442573547,
        "0x75": {
            "len": 147,
            "present": true
        },
        "0x72": {
            "len": 51,
            "present": true
        },
        "errorcount": 0,
        "A_x": -0.01596507988870144,
        "A_z": 0.1592957228422165,
        "0xa4": {
            "len": 19,
            "present": true
        },
        "W_z": -0.0015541655011475086,
        "Lon_bins": 0.98126976,
        "B_bins": -0.9249874949455261,
        "H_bins": 158.70718383789062,
        "0x70": {
            "len": 55,
            "present": true
        },
        "0x88": {
            "len": 135,
            "present": true
        },
        "Lat_bins": 1.0132427800000001,
        "W_y": -0.006653952412307262
    },
    "POSITION": {
        "x": 0.0,
        "y": 0.09549296461045742
    }
}
"""