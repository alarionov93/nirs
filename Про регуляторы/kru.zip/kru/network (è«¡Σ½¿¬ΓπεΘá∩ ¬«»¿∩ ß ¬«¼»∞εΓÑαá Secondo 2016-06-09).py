from urllib.request import urlopen
from json import loads, dumps

url_prefix = 'http://192.168.0.101:8000'

def get_json_url_to_dict(cmd):
	try:
		return loads(urlopen(url_prefix + cmd).read().decode('UTF-8'))
	except Exception as e:
		return dict(
			ok = False,
			error = str(e),
		)

def post_json_url_to_dict(cmd, prm, vars = ()):
	try:
		post = (prm % vars).encode('UTF-8')
		return loads(urlopen(url_prefix + cmd, post).read().decode('UTF-8'))
	except Exception as e:
		return dict(
			ok = False,
			error = str(e),
		)

def ping():
	try:
		return loads(urlopen(url_prefix + '/ping').read().decode('UTF-8'))
	except Exception as e:
		return dict(
			ok = False,
			error = str(e),
		)

def load_img_to_dict(path):
	try:
		return dict(
			img = urlopen(url_prefix + path).read(),
			ok  = True,
		)
	except Exception as e:
		return dict(
			ok = False,
			error = str(e),
		)


if __name__ == "__main__":
	print(ping())
