from chasis import Chasis  #управление шасси
from network import ping # сеть
import io # ввод/вывод
from urllib.request import urlopen # обработка url
from time import sleep # подругаем из time только slaeep
from datetime import datetime
from threading import Thread

# переменные
regulate_end = 0
# исходные
V_target = 0.0 # целевая скорость в м/с
# П
# коэффициенты
Kp = 5.63
#######################################################################
def getV_now():
	return chasis.Position.Vn
#######################################################################
def regulate():# регулятор
	U_result = 0.0
	U_old = 0.0
	Angle_value = chasis.Position.An # угол наклона вдоль корпуса
	Angle_max = 10 # угол, требующий активации тормозной системы
	Timer_max = 10 # время задержки, после остановки
	T_now = 0.0 # текущее время
	T_last = 0.0 # время прошлого цикла
	V_now = 0.0 # текущая скорость в м/с
	# V_target
	E_now = 0.0 # ошибка текущая
	E_last = 0.0 # обшибка прошлого цикла
	S = 0.0 # накопитель времени
	U_reg = 0.0 # результат регулятора
	T_delta = 0.0 # приращение времени
	T_last = datetime.now()
	Stop_signal = 0.0
	# получем текущие значения
	while not regulate_end:
		T_now = datetime.now()
		T_delta = T_now - T_last
		T_delta = T_delta.seconds+T_delta.microseconds/1000000
		V_now = getV_now()
		E_now = V_target - V_now
		if E_now == 0: # накапливаем таймер
			S += T_delta
		if E_now < 0 and (S < Timer_max and S > 0) and (Angle_value > Angle_max and Angle_value < (180 - Angle_max)):
			Stop_signal = 1.0
		else:
			Stop_signal = 0.0
		P = Kp * Stop_signal
		U_reg = P
		U_result = U_old + U_reg
		if U_result = U_old: # если мы вышли в установившийся режим - тормоза активируются
			chasis.Brakes.right = 1
			chasis.Brakes.left = 1
			chasis.Brakes.main = 1
		else:
			chasis.Brakes.right = 0
			chasis.Brakes.left = 0
			chasis.Brakes.main = 0
		U_old = U_result
		sleep(0.05)
		# log.write("%s %s %s %s %s %s %s %s %s %s %s %s\n"\
			# %(T_now, T_last, V_target, V_now, E_now, E_last, S, P, D, I, U_reg, A))
		E_last = E_now
		T_last = T_now
#######################################################################
if __name__ == "__main__": # точка входа
	chasis = Chasis() #создание шасси
	V_target = 1.0
	regulate_thread = Thread(target = regulate) # создание потока
	regulate_thread.start() # запуск потока
	sleep(2)
	V_target = 0.0 # начало воздействия
	sleep(15) # время воздействия
	V_target = 1.0 # конец воздействия
	sleep(6)
	regulate_end = 1 # метка окончания работы потока
	regulate_thread.join()
	chasis.finish()
