from urllib.request import urlopen
from json import loads, dumps
# текущий адрес и порт сервера МРК
url_prefix = 'http://192.168.0.101:8000'
# получение данных с сервера
def get_json_url_to_dict(cmd):
	try:
		# получаем данные, отправляя команду на урл (результат в json)
		return loads(urlopen(url_prefix + cmd).read().decode('UTF-8'))
	except Exception as e:
		return dict(
			ok = False,
			error = str(e),
		)
# отправка данных на сервер
def post_json_url_to_dict(cmd, prm, vars = ()):
	try:
		# создаем запрос
		post = (prm % vars).encode('UTF-8')
		# отправляем запрос?
		return loads(urlopen(url_prefix + cmd, post).read().decode('UTF-8'))
	except Exception as e:
		return dict(
			ok = False,
			error = str(e),
		)
# проверяем доступность сервера
def ping():
	try:
		return loads(urlopen(url_prefix + '/ping').read().decode('UTF-8'))
	except Exception as e:
		return dict(
			ok = False,
			error = str(e),
		)
# точка входа
if __name__ == "__main__":
	print(ping())
