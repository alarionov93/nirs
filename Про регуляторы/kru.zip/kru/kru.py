from tkinter import * #интерфейс
from chasis import Chasis  #управление шасси
from network import ping # сеть
import io # ввод/вывод
from urllib.request import urlopen # обработка url


def add_log(x): # ведение лога в отдельном окне
	try:
		TXT.insert(1.0,x + '\n')
	except NameError:
		print(x)

def profile(x):
	from datetime import datetime
	return "%s %s" % (str(datetime.now()), x)

def build_frameset(x):
	add_log(profile('build_frameset'))
	header  = Frame(x, bd = 1)
	footer  = Frame(x, bd = 1, bg = 'blue')
	pleft   = Frame(x, bd = 1)
	pcenter = Frame(x, bd = 1)
	pright  = Frame(x, bd = 1)
	header.grid( row=0, column=0, sticky="nwse", columnspan=3)
	footer.grid( row=2, column=0, sticky="nwse", columnspan=3)
	pleft.grid(  row=1, column=0, sticky="nwse")
	pcenter.grid(row=1, column=1, sticky="nwse")
	pright.grid( row=1, column=2, sticky="nwse")
	x.columnconfigure(1, weight = 1)
	x.rowconfigure(1, weight = 1)
	return header,footer,pleft,pcenter,pright

def build_header(h):
	add_log(profile('build_header'))
	Label(h, text = 'Ping'      ).grid(row = 0, column = 0)
	Label(h, text = 'Скорость'  ).grid(row = 0, column = 1)
	Label(h, text = 'Скорость ф').grid(row = 0, column = 2)
	Label(h, text = 'Руль'      ).grid(row = 0, column = 3)
	Label(h, text = 'Руль факт' ).grid(row = 0, column = 4)
	Label(h, text = 'Азимут'    ).grid(row = 0, column = 5)
	Label(h, text = 'U 12V (mV)').grid(row = 0, column = 6)
	Label(h, text = 'I 12V (mA)').grid(row = 0, column = 7)
	Label(h, text = 'I 48V (mA)').grid(row = 0, column = 8)
	PNG  = IntVar()
	_ = Checkbutton(h, variable = PNG)
	SPDC = Scale(h, orient = HORIZONTAL, from_ = -MAX_SPD, to = MAX_SPD)
	STPC = Scale(h, orient = HORIZONTAL, from_ =      -19, to =      19)
	SPDR = Scale(h, orient = HORIZONTAL, from_ = -MAX_SPD, to = MAX_SPD)
	STPR = Scale(h, orient = HORIZONTAL, from_ =      -19, to =      19)
	AZM  = Scale(h, orient = HORIZONTAL, from_ =     -180, to =     180)
	U12V = Scale(h, orient = HORIZONTAL, from_ =     9000, to =   15000) # mV
	I12V = Scale(h, orient = HORIZONTAL, from_ =        0, to =   20000) # mA
	I48V = Scale(h, orient = HORIZONTAL, from_ =        0, to =   30000) # mA
	col = 0
	for _ in [_,SPDC,SPDR,STPC,STPR,AZM,U12V,I12V,I48V]:
		_.grid(row=1,column=col)
		col += 1
	return PNG, SPDC, SPDR, STPC, STPR, AZM, U12V, I12V, I48V

def build_footer(x):
	add_log(profile('build_footer'))
	FLS = IntVar()
	FLM = IntVar()
	RGTB= IntVar()
	LFTB= IntVar()
	TXT = Text(x,height=7,width=100,font='Console 12',wrap=WORD)
	TXT.pack()
	return FLS, FLM, RGTB, LFTB, TXT

def build_left_frame(x): # ⭗⭕
	add_log(profile('build_left_frame'))
	Button(x, text='⮉', command = chasis.more   ).grid(row=0,column=0,columnspan=5, sticky="nwse")
	Button(x, text='⮋', command = chasis.less   ).grid(row=2,column=1,columnspan=3, sticky="nwse")
	Button(x, text='⮈', command = chasis.left   ).grid(row=1,column=1,columnspan=1, sticky="nwse")
	Button(x, text='⮊', command = chasis.right  ).grid(row=1,column=3,columnspan=1, sticky="nwse")
	Button(x, text='⏮', command = chasis.lbrake ).grid(row=2,column=0,columnspan=1, sticky="nwse")
	Button(x, text='⏭', command = chasis.rbrake ).grid(row=2,column=4,columnspan=1, sticky="nwse")
	Button(x, text='⚞', command = chasis.lflick ).grid(row=1,column=0,columnspan=1, sticky="nwse")
	Button(x, text='⏸', command = chasis.noflick).grid(row=1,column=2,columnspan=1, sticky="nwse")
	Button(x, text='⚟', command = chasis.rflick ).grid(row=1,column=4,columnspan=1, sticky="nwse")
	Button(x, text='⛔', command = chasis.stop   ).grid(row=3,column=0,columnspan=5, sticky="nwse")

	DSF  = Scale(x, orient = VERTICAL,   from_ =-5000, to = 0) # mm
	DSR  = Scale(x, orient = HORIZONTAL, from_ = 0, to = 5000) # mm
	DSL  = Scale(x, orient = HORIZONTAL, from_ =-5000, to = 0) # mm
	DSB  = Scale(x, orient = VERTICAL,   from_ = 0, to = 5000) # mm

	Button(x, text='0').grid(row=5,column=2,columnspan=1, sticky="nwse")
	DSF.grid(row=4,column=2,columnspan=1)
	DSR.grid(row=5,column=3,columnspan=2, sticky="nwse")
	DSL.grid(row=5,column=0,columnspan=2, sticky="nwse")
	DSB.grid(row=6,column=2,columnspan=1)

	return DSF, DSR, DSL, DSB

def build_center_frame(x):
	add_log(profile('build_center_frame'))
	Img = Label(x)
	Img.grid(row=0,column=0,sticky='nwse')
	x.rowconfigure(0, weight = 1)
	x.columnconfigure(0, weight = 1)
	return Img

def build_right_frame(x): #⮘⮙⮚⮛
	add_log(profile('build_right_frame'))
	Button(x, text='⮙',       command = lambda: show_image(pos = 'up')    ).grid(row=0,column=0,columnspan=3)
	Button(x, text='⮘',       command = lambda: show_image(pos = 'left')  ).grid(row=1,column=0,columnspan=1)
	Button(x, text='⭙',       command = lambda: show_image(pos = 'center')).grid(row=1,column=1,columnspan=1)
	Button(x, text='⮚',       command = lambda: show_image(pos = 'right') ).grid(row=1,column=2,columnspan=1)
	Button(x, text='⮛',       command = lambda: show_image(pos = 'down')  ).grid(row=2,column=0,columnspan=3)
	Button(x, text='left',    command = lambda: show_image(img = 'left')  ).grid(row=3, column=0, columnspan = 3)
	Button(x, text='right',   command = lambda: show_image(img = 'right') ).grid(row=4, column=0, columnspan = 3)
	Button(x, text='360°',    command = lambda: show_image(img = '360°')  ).grid(row=5, column=0, columnspan = 3)	
	Button(x, text='picture', command = lambda: show_image()              ).grid(row=6, column=0, columnspan = 3)	

	P_X  = DoubleVar(x)
	P_Y  = DoubleVar(x)
	P_Vn = DoubleVar(x)
	P_Vh = DoubleVar(x)
	P_Ve = DoubleVar(x)
	Entry(x, textvariable = P_X ).grid(row= 7,column=0, columnspan = 3)
	Entry(x, textvariable = P_Y ).grid(row= 8,column=0, columnspan = 3)
	Entry(x, textvariable = P_Vh).grid(row= 9,column=0, columnspan = 3)
	Entry(x, textvariable = P_Vh).grid(row=10,column=0, columnspan = 3)
	Entry(x, textvariable = P_Ve).grid(row=11,column=0, columnspan = 3)
	return P_X, P_Y, P_Vn, P_Vh, P_Ve

def bind_keys():
	add_log(profile('bind_keys'))
	t.bind('w', chasis.more)
	t.bind('a', chasis.left)
	t.bind('s', chasis.stop)
	t.bind('x', chasis.less)
	t.bind('d', chasis.right)
	t.bind('z', chasis.lbrake)
	t.bind('c', chasis.rbrake)
	t.bind('1', chasis.lflick)
	t.bind('2', chasis.noflick)
	t.bind('3', chasis.rflick)
	t.bind('<Control_L>',chasis.stop)

	t.bind('<Left>',cam.left)
	t.bind('<Right>',cam.right)
	t.bind('<Up>',cam.up)
	t.bind('<Down>',cam.down)
	t.bind('<Control_R>',cam.picture)

	t.bind('<Escape>', exitprog)

def update_form():
	add_log(profile('update_form'))
	CONTROLS = [
		dict(widget = FLS,  control = chasis.Flickers.side,    k =    1),
		dict(widget = FLM,  control = chasis.Flickers.mode,    k =    1),
		dict(widget = U12V, control = chasis.Power.u12v,       k = 1000), # mV
		dict(widget = I12V, control = chasis.Power.i12v,       k = 1000), # mA
		dict(widget = I48V, control = chasis.Power.i48v,       k = 1000), # mA
		dict(widget = STPC, control = chasis.Steering.pos0,    k =    1),
		dict(widget = SPDC, control = chasis.Acceleration.pos0,k =    1),
		dict(widget = STPR, control = chasis.Steering.pos1,    k =    1),
		dict(widget = SPDR, control = chasis.Acceleration.pos1,k =    1),
		dict(widget = RGTB, control = chasis.Brakes.right,     k =    1),
		dict(widget = LFTB, control = chasis.Brakes.left,      k =    1),
		dict(widget = AZM,  control = chasis.Position.azm,     k =    1),
		dict(widget = P_X,  control = chasis.Position.x,       k =    1),
		dict(widget = P_Y,  control = chasis.Position.y,       k =    1),
		dict(widget = P_Vn, control = chasis.Position.Vn,      k =    1),
		dict(widget = P_Vh, control = chasis.Position.Vh,      k =    1),
		dict(widget = P_Ve, control = chasis.Position.Ve,      k =    1),
		dict(widget = DSF,  control = chasis.Distances.front,  k =-1000), # mm
		dict(widget = DSR,  control = chasis.Distances.right,  k = 1000), # mm
		dict(widget = DSL,  control = chasis.Distances.left,   k =-1000), # mm
		dict(widget = DSB,  control = chasis.Distances.rear,   k = 1000), # mm
	]
	for _ in CONTROLS:
		try:
			_['widget'].set(_['control'] * _['k'])
		except TypeError:
			_['widget'].set(-9999)
	t.after(50, update_form)

def update_ping():
	add_log(profile('update_ping'))
	try:
		PNG.set(ping()['time'] != '')
	except Exception as e:
		PNG.set(0)

	t.after(1000, update_ping)

def update_cam():
	add_log(profile('update_cam'))
	try:
		show_image()
	except Exception as e:
		PNG.set(0)
	t.after(500, update_cam)

def show_image(pos = None, img = None):
	add_log(profile('show_image'))
	global III

	if img != None:
		cam.setCurrent(img)

	if pos == 'up':
		cam.up()
	if pos == 'left':
		cam.left()
	if pos == 'center':
		cam.center()
	if pos == 'right':
		cam.right()
	if pos == 'down':
		cam.down()
	try:
		III = ImageTk.PhotoImage(Image.open(cam.picture()))
		IMG.configure(image=III)
	except AttributeError:
		PNG.set(False)

def exitprog(e):
	add_log(profile('exitprog'))
	t.quit()

if __name__ == "__main__": # точка входа
	t = Tk() #создание инф. для создания визуального интерфейса
	chasis = Chasis() #создание шасси
	MAX_SPD = chasis.maxAccPos #


	t.after(500,update_form)

	header,footer,pleft,pcenter,pright = build_frameset(t)
	PNG, SPDC, SPDR, STPC, STPR, AZM, U12V, I12V, I48V = build_header(header)
	FLS, FLM, RGTB, LFTB, TXT = build_footer(footer)
	DSF, DSR, DSL, DSB = build_left_frame(pleft)
	# III = ImageTk.PhotoImage(Image.open(io.BytesIO(urlopen("http://192.168.0.101:8000/view/360").read())))
	IMG = build_center_frame(pcenter)
	P_X, P_Y, P_Vn, P_Vh, P_Ve = build_right_frame(pright)
	t.after(50, update_form)
	t.after(60, update_ping)
	t.after_idle(update_cam)
	bind_keys()
	show_image()
	t.mainloop()
	chasis.stop()
	chasis.finish()
	cam.finish()
